// CircularBuffer.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <thread>
#include <chrono>
#include "CircularErrorBuffer.h"
#include "WindowsStorage.h"

int main()
{
    std::cout << "Hello World!\n";
    WindowsStorage m_WindowsStorage(100U);
    CircularErrorBuffer myCircularErrorBuffer(m_WindowsStorage,100U) ;

    while (1)
    {
        myCircularErrorBuffer.logError(ErrorCode::ERR_FREQ_LOCK);

        std::this_thread::sleep_for(std::chrono::seconds(5));

        myCircularErrorBuffer.logError(ErrorCode::ERR_HW_FAIL);


        std::this_thread::sleep_for(std::chrono::seconds(5));

        myCircularErrorBuffer.logError(ErrorCode::ERR_TIMEOUT);


    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
