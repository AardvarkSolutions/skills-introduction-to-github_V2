#pragma once
#include "IStorageInterface.h"
#include <cstdint>
#include <cstddef>
#if 0

// Replace these with your system values and drivers!
#define FLASH_BASE_ADDRESS     0xA0000000  // Example
#define FLASH_STORAGE_CAPACITY 1024        // Number of uint32_t entries

// These should be your real driver functions, or platform SDK APIs:
extern "C" {
    bool flash_erase_sector(uintptr_t address);
    bool flash_program_word(uintptr_t address, uint32_t word);
    bool flash_read_word(uintptr_t address, uint32_t* word);
}

class FlashStorage : public IStorageInterface {
public:
    FlashStorage(uintptr_t baseAddress, size_t capacity)
        : baseAddress_(baseAddress), capacity_(capacity) {
    }

    bool write(size_t idx, uint32_t entry) override {
        if (idx >= capacity_) return false;
        uintptr_t address = baseAddress_ + idx * sizeof(uint32_t);

        // Optional: Erase-before-write logic (if needed)
        // For some flashes, you must erase the whole sector if changed
        // flash_erase_sector(address);

        // Program word (writes one 32-bit word, hardware-specific)
        return flash_program_word(address, entry);
    }

    bool read(size_t idx, uint32_t& entry) override {
        if (idx >= capacity_) return false;
        uintptr_t address = baseAddress_ + idx * sizeof(uint32_t);
        return flash_read_word(address, &entry);
    }

private:
    uintptr_t baseAddress_;
    size_t capacity_;
};
#endif


