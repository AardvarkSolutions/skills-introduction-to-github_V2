#pragma once

#include <vector>
#include "IStorageInterface.h"

class WindowsStorage : public IStorageInterface {
public:
    WindowsStorage(size_t capacity)
        : data_(capacity, 0) // Initialize vector with 'capacity' elements, set to 0
    {
    }

    // Write the entry at the given index
    bool write(size_t idx, uint32_t entry) override {
        if (idx >= data_.size())
            return false; // Index out of range
        data_[idx] = entry;
        return true;
    }

    // Read the entry at the given index
    bool read(size_t idx, uint32_t& entry) override {
        if (idx >= data_.size())
            return false; // Index out of range
        entry = data_[idx];
        return true;
    }

//private:
    std::vector<uint32_t> data_;
};
